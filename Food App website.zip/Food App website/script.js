// Navigation and toggle functionality
const menuBtn = document.querySelector('#menu-btn');
const searchBtn = document.querySelector('#search-btn');
const cartBtn = document.querySelector('#cart-btn');
const loginBtn = document.querySelector('#login-btn');

const searchForm = document.querySelector('.search-form-container');
const cartContainer = document.querySelector('.cart-container');
const loginForm = document.querySelector('.login-form-container');

menuBtn.onclick = () => {
    document.querySelector('.navbar').classList.toggle('active');
};

searchBtn.onclick = () => {
    searchForm.classList.toggle('active');
    cartContainer.classList.remove('active');
    loginForm.classList.remove('active');
};

cartBtn.onclick = () => {
    cartContainer.classList.toggle('active');
    searchForm.classList.remove('active');
    loginForm.classList.remove('active');
};

loginBtn.onclick = () => {
    loginForm.classList.toggle('active');
    searchForm.classList.remove('active');
    cartContainer.classList.remove('active');
};

document.querySelector('.close-cart')?.addEventListener('click', () => {
    cartContainer.classList.remove('active');
});

// Slideshow logic
let slides = document.querySelectorAll('.slide');
let index = 0;

function showSlide(i) {
    slides.forEach(slide => slide.classList.remove('active'));
    slides[i].classList.add('active');
}

document.querySelector('#next-slide')?.addEventListener('click', () => {
    index = (index + 1) % slides.length;
    showSlide(index);
});

document.querySelector('#prev-slide')?.addEventListener('click', () => {
    index = (index - 1 + slides.length) % slides.length;
    showSlide(index);
});

// Cart system
let cartItems = [];
const cartItemsContainer = document.querySelector('.cart-items');
const cartTotal = document.querySelector('.cart-total-value');
const cartCount = document.querySelector('.cart-count');

document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', function () {
        const productBox = btn.closest('.box');
        const id = productBox.getAttribute('data-id');
        const name = productBox.querySelector('h3').innerText;
        const priceText = productBox.querySelector('.price').innerText;
        const price = parseFloat(priceText.split('$')[1]);

        cartItems.push({ id, name, price });
        updateCart();
    });
});

function updateCart() {
    cartItemsContainer.innerHTML = '';
    let total = 0;

    cartItems.forEach(item => {
        total += item.price;
        const div = document.createElement('div');
        div.className = 'cart-item d-flex justify-content-between align-items-center py-2';
        div.innerHTML = `
            <span>${item.name}</span>
            <span>$${item.price.toFixed(2)}</span>
        `;
        cartItemsContainer.appendChild(div);
    });

    cartTotal.textContent = total.toFixed(2);
    cartCount.textContent = cartItems.length;
}

document.getElementById('checkout-btn')?.addEventListener('click', () => {
    const total = cartTotal.innerText;
    alert(`Checkout successful!\nYour total is $${total}`);
    cartItems = [];
    updateCart();
});

// Lightbox Gallery
const lightboxModal = document.querySelector('.lightbox-modal');
const lightboxImg = document.getElementById('lightbox-img');
const closeLightbox = document.querySelector('.close-lightbox');

document.querySelectorAll('.gallery-btn').forEach(btn => {
    btn.addEventListener('click', e => {
        e.preventDefault();
        const imgSrc = btn.getAttribute('href');
        lightboxImg.src = imgSrc;
        lightboxModal.style.display = 'flex';
    });
});

closeLightbox?.addEventListener('click', () => {
    lightboxModal.style.display = 'none';
});

window.addEventListener('click', e => {
    if (e.target === lightboxModal) {
        lightboxModal.style.display = 'none';
    }
});

// Navigation section toggle
const navLinks = document.querySelectorAll('.navbar a');

navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const id = link.getAttribute('href');
        document.querySelectorAll('section').forEach(section => {
            section.style.display = 'none';
        });
        if (id === '#') {
            document.querySelector('#home').style.display = 'block';
        } else {
            document.querySelector(id).style.display = 'block';
        }
    });
});

// Show only Home section on load
window.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('section').forEach(section => {
        section.style.display = 'none';
    });
    document.querySelector('#home').style.display = 'block';
});

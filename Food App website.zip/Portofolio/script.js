// Smooth Scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

// Theme Toggle Button
const toggleBtn = document.createElement('button');
toggleBtn.innerText = '🌙';
toggleBtn.setAttribute('id', 'themeToggle');
toggleBtn.style.position = 'fixed';
toggleBtn.style.bottom = '20px';
toggleBtn.style.right = '20px';
toggleBtn.style.zIndex = '1000';
toggleBtn.style.padding = '10px 14px';
toggleBtn.style.borderRadius = '50%';
toggleBtn.style.border = 'none';
toggleBtn.style.backgroundColor = '#f9d6d6';
toggleBtn.style.cursor = 'pointer';
toggleBtn.style.boxShadow = '0 2px 6px rgba(0,0,0,0.2)';
toggleBtn.style.transition = 'all 0.3s ease';
document.body.appendChild(toggleBtn);

// Load from localStorage
let darkMode = localStorage.getItem('theme') === 'dark';

// Apply Theme Function
function applyTheme(isDark) {
  darkMode = isDark;
  localStorage.setItem('theme', darkMode ? 'dark' : 'light');

  // Body Colors
  document.body.style.transition = 'background-color 0.5s ease, color 0.5s ease';
  document.body.style.backgroundColor = darkMode ? "#f3e5f5" : "#fff7f0";
  document.body.style.color = darkMode ? "#4a148c" : "#333";

  // Navbar
  document.querySelectorAll('.navbar').forEach(el => {
    el.classList.remove('bg-white', 'bg-dark', 'text-white');
    el.style.backgroundColor = darkMode ? '#e1bee7' : '#fff0f5';
    el.style.transition = 'all 0.3s ease';
  });

  // Headings & Links
  document.querySelectorAll('h1, h2, h3, h4, h5, h6, p, a, small, label, .section-title').forEach(el => {
    el.style.transition = 'color 0.3s ease';
    el.style.color = darkMode ? "#6a1b9a" : "#f06292";
  });

  // Cards/Boxes
  document.querySelectorAll('.bg-light').forEach(el => {
    el.style.transition = 'all 0.3s ease';
    el.style.backgroundColor = darkMode ? "#fce4ec" : "#fff6f2";
    el.style.color = darkMode ? "#4a148c" : "#333";
    el.style.borderColor = darkMode ? "#ce93d8" : "#f2dede";
  });

  // Buttons
  document.querySelectorAll('.btn').forEach(btn => {
    btn.style.transition = 'all 0.3s ease';
    btn.classList.remove('btn-primary', 'btn-light');
    btn.style.backgroundColor = darkMode ? '#ba68c8' : '#f48fb1';
    btn.style.color = '#fff';
  });

  // Contact section background
  const contactSection = document.querySelector('.contact-bg');
  if (contactSection) {
    contactSection.style.transition = 'all 0.3s ease';
    contactSection.style.backgroundColor = darkMode ? "#fce4ec" : "#ffe6e6";
  }

  // Toggle button itself
  toggleBtn.innerText = darkMode ? '☀️' : '🌙';
  toggleBtn.style.backgroundColor = darkMode ? '#ce93d8' : '#f9d6d6';
  toggleBtn.style.color = darkMode ? '#fff' : '#000';
}

// Toggle on click
toggleBtn.addEventListener('click', () => {
  applyTheme(!darkMode);
});

// On page load
applyTheme(darkMode);


// Handle Google Map Search
function search() {
  const location = document.getElementById('searchLocation').value;
  const encodedLocation = encodeURIComponent(location || 'Islamabad');
  document.getElementById('map').src = `https://maps.google.com/maps?q=${encodedLocation}&output=embed`;
  alert('Search is a demo — filtering is not implemented.');
}

  const doctors = [
    {name: "Dr. Ayesha Khan", spec: "Dermatologist", img: "women/45"},
    {name: "Dr. Usman Rafiq", spec: "Cardiologist", img: "men/10"},
    {name: "Dr. Sana Tariq", spec: "Neurologist", img: "women/11"},
    {name: "Dr. Ali Shah", spec: "Orthopedic", img: "men/5"},
    {name: "Dr. Zainab Malik", spec: "Pediatrician", img: "women/22"},
    {name: "Dr. Kamran Aziz", spec: "Psychiatrist", img: "men/9"},
    {name: "Dr. Mariam Noor", spec: "Radiologist", img: "women/19"},
    {name: "Dr. Imran Basit", spec: "ENT", img: "men/21"},
    {name: "Dr. Hira Faisal", spec: "Gastroenterologist", img: "women/24"},
    {name: "Dr. Asif Iqbal", spec: "Urologist", img: "men/28"},
    {name: "Dr. Farah Javed", spec: "Oncologist", img: "women/29"},
    {name: "Dr. Salman Qureshi", spec: "Surgeon", img: "men/6"},
    {name: "Dr. Rabia Anwar", spec: "Dentist", img: "women/30"},
    {name: "Dr. Bilal Ahmed", spec: "Cardiologist", img: "men/7"},
    {name: "Dr. Nida Kiran", spec: "Ophthalmologist", img: "women/35"},
    {name: "Dr. Shahid Farooq", spec: "General Physician", img: "men/8"},
    {name: "Dr. Hina Gul", spec: "Dermatologist", img: "women/40"},
    {name: "Dr. Waqas Zafar", spec: "Orthopedic", img: "men/12"},
    {name: "Dr. Tehmina Rana", spec: "Psychologist", img: "women/44"},
    {name: "Dr. Zeeshan Tariq", spec: "ENT Specialist", img: "men/13"}
  ];

  const doctorContainer = document.getElementById("doctorContainer");

 // Render all doctors by default
function renderDoctors(list) {
  const container = document.getElementById("doctorContainer");
  container.innerHTML = list.map(doc => `
    <div class="doctor-card card shadow-sm">
      <img src="https://randomuser.me/api/portraits/${doc.img}.jpg" class="card-img-top rounded-top" alt="${doc.name}">
      <div class="card-body text-center">
        <h6>${doc.name}</h6>
        <p class="text-muted small">${doc.spec}</p>
        <button class="btn btn-sm btn-outline-primary w-100" onclick="bookAppointment('${doc.name}')">Book</button>
      </div>
    </div>
  `).join('');
}

document.addEventListener("DOMContentLoaded", () => {
  renderDoctors(doctors);

  // Clickable specialties filter
  document.getElementById("specialtyList").addEventListener("click", e => {
    if (e.target.tagName === "SPAN") {
      const specialty = e.target.getAttribute("data-spec");
      const filtered = doctors.filter(doc => doc.spec.includes(specialty));
      renderDoctors(filtered);
    }
  });
});

  function bookAppointment(name) {
    const date = prompt(`Book appointment with ${name}\nPlease enter preferred date (e.g. 2025-08-10):`);
    if (date) alert(`Appointment confirmed with ${name} on ${date}`);
  }
